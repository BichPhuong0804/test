# setup
docker compose up -d

# check bot logs
docker compose logs -f bot