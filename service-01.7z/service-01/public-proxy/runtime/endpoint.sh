#!/bin/bash

service ssh restart
service nginx restart
sleep infinity